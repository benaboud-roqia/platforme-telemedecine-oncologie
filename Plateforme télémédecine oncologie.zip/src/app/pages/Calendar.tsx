import { motion } from "motion/react";
import { Calendar as CalendarIcon, Plus, Clock, Video, Pill, Activity, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";

const appointments = [
  {
    id: 1,
    date: "2026-04-15",
    time: "10:00",
    title: "Consultation Dr. Belkacem",
    type: "Psychologue",
    patient: "Mme Fatima B.",
    icon: Video,
    color: "bg-secondary"
  },
  {
    id: 2,
    date: "2026-04-15",
    time: "14:00",
    title: "Cycle chimio #4",
    type: "Traitement",
    patient: "Mme Fatima B.",
    icon: Pill,
    color: "bg-primary"
  },
  {
    id: 3,
    date: "2026-04-16",
    time: "09:30",
    title: "Consultation suivi",
    type: "Oncologue",
    patient: "M. Karim H.",
    icon: Activity,
    color: "bg-chart-3"
  },
  {
    id: 4,
    date: "2026-04-17",
    time: "11:00",
    title: "Scanner de contrôle",
    type: "Imagerie",
    patient: "Mme Sarah L.",
    icon: Activity,
    color: "bg-chart-4"
  },
  {
    id: 5,
    date: "2026-04-20",
    time: "15:00",
    title: "Résultats analyses",
    type: "Consultation",
    patient: "M. Ahmed K.",
    icon: Video,
    color: "bg-secondary"
  },
];

const reminders = [
  {
    time: "08:00",
    title: "Dexaméthasone 4mg",
    patient: "M. Karim H.",
    type: "medication"
  },
  {
    time: "14:00",
    title: "Rendez-vous chimio",
    patient: "Mme Fatima B.",
    type: "appointment"
  },
  {
    time: "20:00",
    title: "Ondansétron 8mg",
    patient: "Mme Fatima B.",
    type: "medication"
  },
];

const upcomingDays = [
  { day: "Lun", date: 13, current: true },
  { day: "Mar", date: 14, current: false },
  { day: "Mer", date: 15, current: false },
  { day: "Jeu", date: 16, current: false },
  { day: "Ven", date: 17, current: false },
  { day: "Sam", date: 18, current: false },
  { day: "Dim", date: 19, current: false },
];

export function Calendar() {
  const [selectedDate, setSelectedDate] = useState("2026-04-15");

  const todayAppointments = appointments.filter(apt => apt.date === selectedDate);

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl mb-2">Agenda & Rappels</h1>
          <p className="text-muted-foreground">
            Gestion des rendez-vous et rappels de traitements
          </p>
        </div>
        <button className="px-6 py-3 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Nouveau rendez-vous
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-3 space-y-6"
        >
          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl">Avril 2026</h2>
              <div className="flex items-center gap-2">
                <button className="p-2 hover:bg-muted rounded-lg transition-colors">
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <button className="p-2 hover:bg-muted rounded-lg transition-colors">
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-7 gap-2 mb-4">
              {upcomingDays.map((day) => (
                <button
                  key={day.date}
                  onClick={() => setSelectedDate(`2026-04-${day.date}`)}
                  className={`p-4 rounded-xl transition-all ${
                    selectedDate === `2026-04-${day.date}`
                      ? "bg-primary text-primary-foreground shadow-lg"
                      : day.current
                      ? "bg-secondary/20 text-secondary"
                      : "bg-muted/50 hover:bg-muted"
                  }`}
                >
                  <p className="text-xs mb-1">{day.day}</p>
                  <p className="text-2xl font-bold">{day.date}</p>
                </button>
              ))}
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <h2 className="text-2xl mb-6">
              Rendez-vous du {new Date(selectedDate).toLocaleDateString('fr-DZ', {
                weekday: 'long',
                day: 'numeric',
                month: 'long'
              })}
            </h2>
            {todayAppointments.length > 0 ? (
              <div className="space-y-4">
                {todayAppointments.map((appointment) => (
                  <motion.div
                    key={appointment.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="p-5 bg-muted/50 border border-border rounded-xl hover:border-primary transition-all"
                  >
                    <div className="flex items-start gap-4">
                      <div className={`${appointment.color} p-3 rounded-xl`}>
                        <appointment.icon className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-semibold text-lg mb-1">
                              {appointment.title}
                            </h3>
                            <p className="text-sm text-muted-foreground mb-1">
                              {appointment.patient}
                            </p>
                            <div className="flex items-center gap-3 text-sm">
                              <span className="flex items-center gap-1 text-primary">
                                <Clock className="w-4 h-4" />
                                {appointment.time}
                              </span>
                              <span className="px-2 py-1 bg-primary/10 text-primary rounded text-xs font-medium">
                                {appointment.type}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2 mt-3">
                          <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                            Voir détails
                          </button>
                          <button className="px-4 py-2 border border-border rounded-lg text-sm font-medium hover:bg-muted transition-colors">
                            Modifier
                          </button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <CalendarIcon className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-muted-foreground">
                  Aucun rendez-vous prévu pour cette date
                </p>
              </div>
            )}
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <h2 className="text-2xl mb-6">Vue mensuelle</h2>
            <div className="grid grid-cols-7 gap-2 mb-2">
              {["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"].map((day) => (
                <div key={day} className="text-center text-sm font-medium text-muted-foreground p-2">
                  {day}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-2">
              {[...Array(30)].map((_, i) => {
                const date = i + 1;
                const hasAppointment = appointments.some(
                  apt => apt.date === `2026-04-${String(date).padStart(2, '0')}`
                );
                return (
                  <button
                    key={i}
                    className={`aspect-square p-2 rounded-lg text-sm transition-all relative ${
                      date === 15
                        ? "bg-primary text-primary-foreground font-semibold"
                        : hasAppointment
                        ? "bg-secondary/20 text-secondary font-medium"
                        : "hover:bg-muted"
                    }`}
                  >
                    {date}
                    {hasAppointment && (
                      <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 bg-secondary rounded-full"></span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-6"
        >
          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <Clock className="w-6 h-6 text-secondary" />
              <h2 className="text-xl">Rappels du jour</h2>
            </div>
            <div className="space-y-3">
              {reminders.map((reminder, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-xl ${
                    reminder.type === "medication"
                      ? "bg-primary/10 border border-primary/20"
                      : "bg-secondary/10 border border-secondary/20"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-semibold text-sm">{reminder.time}</span>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      reminder.type === "medication"
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-white"
                    }`}>
                      {reminder.type === "medication" ? <Pill className="w-3 h-3" /> : <CalendarIcon className="w-3 h-3" />}
                    </span>
                  </div>
                  <p className="font-medium mb-1">{reminder.title}</p>
                  <p className="text-xs text-muted-foreground">{reminder.patient}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground rounded-2xl p-6 shadow-lg">
            <CalendarIcon className="w-12 h-12 mb-4 opacity-90" />
            <h3 className="text-xl mb-2">Rappels intelligents</h3>
            <p className="text-sm text-primary-foreground/90 mb-4">
              Notifications automatiques pour les rendez-vous, prises de médicaments et examens de contrôle.
            </p>
            <button className="w-full px-4 py-3 bg-white/20 backdrop-blur-sm rounded-lg font-medium hover:bg-white/30 transition-colors">
              Configurer
            </button>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <h3 className="font-semibold mb-4">Statistiques</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">RDV ce mois</span>
                <span className="font-semibold">18</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Consultations</span>
                <span className="font-semibold">12</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Traitements</span>
                <span className="font-semibold">4</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Examens</span>
                <span className="font-semibold">2</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
