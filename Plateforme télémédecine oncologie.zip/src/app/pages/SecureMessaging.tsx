import { motion } from "motion/react";
import { MessageSquare, Send, Paperclip, Shield, Search, MoreVertical } from "lucide-react";
import { useState } from "react";

const conversations = [
  {
    id: 1,
    name: "Mme Fatima B.",
    lastMessage: "Merci docteur pour vos conseils",
    time: "09:30",
    unread: 0,
    avatar: "FB"
  },
  {
    id: 2,
    name: "M. Karim H.",
    lastMessage: "Les résultats sont-ils disponibles ?",
    time: "Hier",
    unread: 2,
    avatar: "KH"
  },
  {
    id: 3,
    name: "Dr. Ahmed Bensalem",
    lastMessage: "Réunion demain 14h",
    time: "Hier",
    unread: 0,
    avatar: "AB"
  },
  {
    id: 4,
    name: "Équipe soignante",
    lastMessage: "Nouveau protocole validé",
    time: "10 Avr",
    unread: 5,
    avatar: "ES"
  },
];

const messages = [
  {
    id: 1,
    sender: "patient",
    name: "Mme Fatima B.",
    message: "Bonjour docteur, j'ai une question concernant mes médicaments",
    time: "09:15",
    avatar: "FB"
  },
  {
    id: 2,
    sender: "me",
    message: "Bonjour Madame Fatima, je vous écoute. De quel médicament s'agit-il ?",
    time: "09:18"
  },
  {
    id: 3,
    sender: "patient",
    name: "Mme Fatima B.",
    message: "C'est pour l'Ondansétron. Je dois le prendre avant ou après les repas ?",
    time: "09:20",
    avatar: "FB"
  },
  {
    id: 4,
    sender: "me",
    message: "Vous pouvez le prendre indépendamment des repas. L'important est de respecter les horaires pour une efficacité optimale contre les nausées.",
    time: "09:22"
  },
  {
    id: 5,
    sender: "patient",
    name: "Mme Fatima B.",
    message: "Merci docteur pour vos conseils 🙏",
    time: "09:30",
    avatar: "FB"
  },
];

export function SecureMessaging() {
  const [selectedConversation, setSelectedConversation] = useState(conversations[0]);
  const [messageText, setMessageText] = useState("");

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl mb-2">Messagerie sécurisée</h1>
        <p className="text-muted-foreground flex items-center gap-2">
          <Shield className="w-4 h-4 text-primary" />
          Communication chiffrée de bout en bout
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-1 bg-card border border-border rounded-2xl shadow-sm overflow-hidden"
        >
          <div className="p-4 border-b border-border">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Rechercher..."
                className="w-full pl-10 pr-4 py-3 bg-muted/50 border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          <div className="overflow-y-auto max-h-[600px]">
            {conversations.map((conv) => (
              <button
                key={conv.id}
                onClick={() => setSelectedConversation(conv)}
                className={`w-full p-4 border-b border-border hover:bg-muted/50 transition-colors text-left ${
                  selectedConversation.id === conv.id ? "bg-primary/5" : ""
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                    <span className="text-primary font-semibold">{conv.avatar}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="font-medium truncate">{conv.name}</p>
                      <span className="text-xs text-muted-foreground">{conv.time}</span>
                    </div>
                    <p className="text-sm text-muted-foreground truncate">
                      {conv.lastMessage}
                    </p>
                  </div>
                  {conv.unread > 0 && (
                    <div className="w-6 h-6 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                      <span className="text-xs text-white font-semibold">{conv.unread}</span>
                    </div>
                  )}
                </div>
              </button>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-3 bg-card border border-border rounded-2xl shadow-sm flex flex-col"
        >
          <div className="p-6 border-b border-border flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                <span className="text-primary font-semibold">{selectedConversation.avatar}</span>
              </div>
              <div>
                <p className="font-semibold text-lg">{selectedConversation.name}</p>
                <p className="text-sm text-muted-foreground">En ligne</p>
              </div>
            </div>
            <button className="p-2 hover:bg-muted rounded-lg transition-colors">
              <MoreVertical className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 p-6 overflow-y-auto max-h-[500px] space-y-4">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === "me" ? "justify-end" : "justify-start"}`}
              >
                <div className={`flex gap-3 max-w-[70%] ${msg.sender === "me" ? "flex-row-reverse" : ""}`}>
                  {msg.sender !== "me" && (
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-primary font-semibold text-sm">{msg.avatar}</span>
                    </div>
                  )}
                  <div>
                    <div className={`p-4 rounded-2xl ${
                      msg.sender === "me"
                        ? "bg-primary text-primary-foreground rounded-br-sm"
                        : "bg-muted/50 rounded-bl-sm"
                    }`}>
                      <p>{msg.message}</p>
                    </div>
                    <p className={`text-xs text-muted-foreground mt-1 ${
                      msg.sender === "me" ? "text-right" : "text-left"
                    }`}>
                      {msg.time}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="p-6 border-t border-border">
            <div className="flex items-end gap-3">
              <button className="p-3 hover:bg-muted rounded-xl transition-colors">
                <Paperclip className="w-5 h-5 text-muted-foreground" />
              </button>
              <div className="flex-1">
                <textarea
                  value={messageText}
                  onChange={(e) => setMessageText(e.target.value)}
                  placeholder="Tapez votre message..."
                  rows={2}
                  className="w-full p-3 bg-muted/50 border border-border rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-primary"
                />
              </div>
              <button className="p-3 bg-primary text-primary-foreground rounded-xl hover:bg-primary/90 transition-colors">
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-primary/10 border border-primary/20 rounded-2xl p-6"
      >
        <div className="flex items-start gap-4">
          <Shield className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
          <div>
            <h3 className="font-semibold mb-2">Sécurité et confidentialité</h3>
            <p className="text-sm text-muted-foreground">
              Tous les messages sont chiffrés de bout en bout. Les pièces jointes médicales sont stockées de manière sécurisée et conforme au RGPD. Les conversations sont archivées dans le dossier médical du patient.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
