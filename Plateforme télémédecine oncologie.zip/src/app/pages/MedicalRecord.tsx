import { motion } from "motion/react";
import { FileText, Download, Upload, Eye, Search, Filter } from "lucide-react";
import { useState } from "react";

const patients = [
  { id: 1, name: "Mme Fatima B.", age: 58, diagnosis: "Cancer du sein - Stade II", lastUpdate: "12 Avril 2026" },
  { id: 2, name: "M. Karim H.", age: 62, diagnosis: "Cancer du poumon - Stade III", lastUpdate: "10 Avril 2026" },
  { id: 3, name: "Mme Sarah L.", age: 45, diagnosis: "Lymphome de Hodgkin", lastUpdate: "08 Avril 2026" },
];

const medicalFiles = [
  { type: "IRM", date: "10 Avril 2026", description: "IRM cérébrale - Contrôle", size: "24 MB" },
  { type: "Scanner", date: "05 Avril 2026", description: "Scanner thoracique", size: "18 MB" },
  { type: "Biopsie", date: "01 Avril 2026", description: "Résultats anatomo-pathologie", size: "2 MB" },
  { type: "Analyses", date: "29 Mars 2026", description: "Bilan sanguin complet", size: "1 MB" },
  { type: "PET-Scan", date: "22 Mars 2026", description: "PET-Scan corps entier", size: "32 MB" },
];

const timeline = [
  { date: "12 Avril 2026", event: "Consultation de suivi", description: "État stable, poursuite du traitement" },
  { date: "05 Avril 2026", event: "Scanner de contrôle", description: "Résultats satisfaisants" },
  { date: "29 Mars 2026", event: "Cycle chimio #4", description: "Tolérance correcte" },
  { date: "15 Mars 2026", event: "Cycle chimio #3", description: "Effets secondaires modérés" },
];

export function MedicalRecord() {
  const [selectedPatient, setSelectedPatient] = useState(patients[0]);

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl mb-2">Dossier médical électronique</h1>
          <p className="text-muted-foreground">
            Gestion centralisée des dossiers patients
          </p>
        </div>
        <button className="px-6 py-3 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors flex items-center gap-2">
          <Upload className="w-5 h-5" />
          Importer un document
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-1 bg-card border border-border rounded-2xl p-6 shadow-sm"
        >
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                placeholder="Rechercher un patient..."
                className="w-full pl-10 pr-4 py-3 bg-muted/50 border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
          </div>

          <h3 className="font-medium mb-4">Liste des patients</h3>
          <div className="space-y-2">
            {patients.map((patient) => (
              <button
                key={patient.id}
                onClick={() => setSelectedPatient(patient)}
                className={`w-full text-left p-4 rounded-xl transition-all ${
                  selectedPatient.id === patient.id
                    ? "bg-primary text-primary-foreground shadow-lg"
                    : "bg-muted/50 hover:bg-muted"
                }`}
              >
                <p className="font-medium mb-1">{patient.name}</p>
                <p className={`text-sm ${
                  selectedPatient.id === patient.id
                    ? "text-primary-foreground/80"
                    : "text-muted-foreground"
                }`}>
                  {patient.age} ans
                </p>
              </button>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-3 space-y-6"
        >
          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <div className="flex items-start justify-between mb-6">
              <div>
                <h2 className="text-2xl mb-2">{selectedPatient.name}</h2>
                <p className="text-muted-foreground mb-1">{selectedPatient.age} ans</p>
                <p className="text-primary font-medium">{selectedPatient.diagnosis}</p>
              </div>
              <div className="text-right">
                <p className="text-sm text-muted-foreground mb-1">Dernière mise à jour</p>
                <p className="font-medium">{selectedPatient.lastUpdate}</p>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4 p-4 bg-muted/50 rounded-xl">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Groupe sanguin</p>
                <p className="font-medium">O+</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Allergies</p>
                <p className="font-medium">Pénicilline</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Traitement actuel</p>
                <p className="font-medium">AC-T</p>
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl">Documents médicaux</h3>
              <button className="p-2 hover:bg-muted rounded-lg transition-colors">
                <Filter className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-3">
              {medicalFiles.map((file, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-4 bg-muted/50 rounded-xl hover:bg-muted transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                      <FileText className="w-6 h-6 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium mb-1">{file.description}</p>
                      <p className="text-sm text-muted-foreground">
                        {file.type} • {file.date} • {file.size}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="p-2 hover:bg-primary/10 rounded-lg transition-colors">
                      <Eye className="w-5 h-5 text-primary" />
                    </button>
                    <button className="p-2 hover:bg-primary/10 rounded-lg transition-colors">
                      <Download className="w-5 h-5 text-primary" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <h3 className="text-xl mb-6">Historique médical</h3>
            <div className="relative">
              <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-border"></div>
              <div className="space-y-6">
                {timeline.map((item, index) => (
                  <div key={index} className="relative pl-12">
                    <div className="absolute left-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                      <div className="w-3 h-3 bg-primary-foreground rounded-full"></div>
                    </div>
                    <div className="p-4 bg-muted/50 rounded-xl">
                      <p className="text-sm text-muted-foreground mb-1">{item.date}</p>
                      <p className="font-medium mb-1">{item.event}</p>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
