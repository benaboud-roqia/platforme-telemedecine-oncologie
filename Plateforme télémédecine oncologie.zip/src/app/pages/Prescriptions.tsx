import { motion } from "motion/react";
import { Pill, Plus, AlertTriangle, CheckCircle2, Clock } from "lucide-react";

const activePrescriptions = [
  {
    medication: "Paclitaxel",
    dosage: "175 mg/m²",
    frequency: "Tous les 21 jours",
    nextDose: "15 Avril 2026",
    cycle: "Cycle 4/6",
    status: "active"
  },
  {
    medication: "Doxorubicine",
    dosage: "60 mg/m²",
    frequency: "Tous les 21 jours",
    nextDose: "15 Avril 2026",
    cycle: "Cycle 4/6",
    status: "active"
  },
  {
    medication: "Ondansétron",
    dosage: "8 mg",
    frequency: "2x par jour",
    nextDose: "Aujourd'hui 20h",
    cycle: "Continu",
    status: "active"
  },
];

const protocols = [
  {
    name: "AC-T (Adriamycine-Cyclophosphamide-Taxol)",
    indication: "Cancer du sein adjuvant",
    duration: "18 semaines",
    cycles: "6 cycles"
  },
  {
    name: "FOLFOX",
    indication: "Cancer colorectal",
    duration: "12 semaines",
    cycles: "6 cycles"
  },
  {
    name: "Cisplatine-Étoposide",
    indication: "Cancer du poumon à petites cellules",
    duration: "12 semaines",
    cycles: "4 cycles"
  },
];

const interactions = [
  {
    drugs: "Paclitaxel + Doxorubicine",
    severity: "Modérée",
    description: "Risque accru de cardiotoxicité - Surveillance ECG recommandée"
  },
  {
    drugs: "Ondansétron + Doxorubicine",
    severity: "Faible",
    description: "Pas d'interaction cliniquement significative"
  },
];

export function Prescriptions() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl mb-2">Prescriptions & Protocoles</h1>
          <p className="text-muted-foreground">
            Gestion des ordonnances et protocoles de chimiothérapie
          </p>
        </div>
        <button className="px-6 py-3 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors flex items-center gap-2">
          <Plus className="w-5 h-5" />
          Nouvelle ordonnance
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="lg:col-span-2 space-y-6"
        >
          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <Pill className="w-6 h-6 text-primary" />
              <h2 className="text-2xl">Prescriptions actives</h2>
            </div>
            <div className="space-y-4">
              {activePrescriptions.map((prescription, index) => (
                <div
                  key={index}
                  className="p-5 bg-muted/50 border border-border rounded-xl hover:border-primary transition-all"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-semibold text-lg mb-1">
                        {prescription.medication}
                      </h3>
                      <p className="text-muted-foreground mb-2">
                        {prescription.dosage} • {prescription.frequency}
                      </p>
                      <div className="flex items-center gap-4 text-sm">
                        <span className="flex items-center gap-1 text-primary">
                          <Clock className="w-4 h-4" />
                          {prescription.nextDose}
                        </span>
                        <span className="px-2 py-1 bg-primary/10 text-primary rounded-full text-xs font-medium">
                          {prescription.cycle}
                        </span>
                      </div>
                    </div>
                    <CheckCircle2 className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex gap-2">
                    <button className="flex-1 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                      Voir détails
                    </button>
                    <button className="px-4 py-2 border border-border rounded-lg text-sm font-medium hover:bg-muted transition-colors">
                      Modifier
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <h2 className="text-2xl mb-6">Protocoles disponibles</h2>
            <div className="space-y-3">
              {protocols.map((protocol, index) => (
                <div
                  key={index}
                  className="p-4 bg-muted/50 rounded-xl hover:bg-muted transition-colors"
                >
                  <h3 className="font-semibold mb-2">{protocol.name}</h3>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground mb-1">Indication</p>
                      <p className="font-medium">{protocol.indication}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground mb-1">Durée</p>
                      <p className="font-medium">{protocol.duration}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground mb-1">Cycles</p>
                      <p className="font-medium">{protocol.cycles}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-6"
        >
          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <AlertTriangle className="w-6 h-6 text-destructive" />
              <h2 className="text-xl">Interactions médicamenteuses</h2>
            </div>
            <div className="space-y-4">
              {interactions.map((interaction, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-xl border-l-4 ${
                    interaction.severity === "Modérée"
                      ? "bg-secondary/5 border-secondary"
                      : "bg-muted/50 border-primary"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-medium text-sm">{interaction.drugs}</p>
                    <span
                      className={`text-xs px-2 py-1 rounded-full ${
                        interaction.severity === "Modérée"
                          ? "bg-secondary/20 text-secondary"
                          : "bg-primary/20 text-primary"
                      }`}
                    >
                      {interaction.severity}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {interaction.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground rounded-2xl p-6 shadow-lg">
            <h3 className="text-xl mb-3">Rappel important</h3>
            <p className="text-sm text-primary-foreground/90 mb-4">
              Tous les protocoles de chimiothérapie doivent être validés par le comité oncologique avant administration.
            </p>
            <button className="w-full px-4 py-3 bg-white/20 backdrop-blur-sm rounded-lg font-medium hover:bg-white/30 transition-colors">
              Consulter le protocole
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
