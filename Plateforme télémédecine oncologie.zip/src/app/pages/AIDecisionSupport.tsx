import { motion } from "motion/react";
import { Brain, Sparkles, FileSearch, AlertCircle, TrendingUp } from "lucide-react";

const aiSuggestions = [
  {
    type: "Protocole recommandé",
    confidence: 94,
    title: "AC-T adapté pour patiente",
    description: "Basé sur le stade II, l'âge et les biomarqueurs, le protocole AC-T est recommandé avec ajustement de la dose de Doxorubicine.",
    evidence: ["Essai clinique BCIRG 001", "Métaanalyse 2023"],
  },
  {
    type: "Essai clinique",
    confidence: 87,
    title: "Étude KEYNOTE-522 éligible",
    description: "Patient éligible pour l'essai sur l'immunothérapie néoadjuvante. Critères d'inclusion remplis.",
    evidence: ["Critères KEYNOTE-522", "Statut PD-L1 positif"],
  },
  {
    type: "Anomalie détectée",
    confidence: 76,
    title: "Variation dans scanner thoracique",
    description: "L'IA a détecté une légère augmentation de l'opacité lobaire supérieure droite comparé au scanner précédent.",
    evidence: ["Analyse radiomique", "Comparaison temporelle"],
  },
];

const analysisResults = [
  { metric: "Risque de récidive", value: "Modéré (23%)", status: "warning" },
  { metric: "Réponse au traitement", value: "Positive (78%)", status: "success" },
  { metric: "Toxicité prédite", value: "Faible", status: "success" },
  { metric: "Survie à 5 ans", value: "82%", status: "success" },
];

const clinicalTrials = [
  {
    id: "NCT04567890",
    name: "Immunothérapie + Chimio néoadjuvante",
    phase: "Phase III",
    location: "CHU Mustapha, Alger",
    eligible: true
  },
  {
    id: "NCT04123456",
    name: "Thérapie ciblée HER2+",
    phase: "Phase II",
    location: "CPMC, Alger",
    eligible: false
  },
];

export function AIDecisionSupport() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl mb-2">IA d'aide à la décision clinique</h1>
        <p className="text-muted-foreground">
          Analyse intelligente pour optimiser les décisions thérapeutiques
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {analysisResults.map((result, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-card border border-border rounded-2xl p-6 shadow-sm"
          >
            <p className="text-sm text-muted-foreground mb-2">{result.metric}</p>
            <p className={`text-2xl font-bold ${
              result.status === "success" ? "text-primary" : "text-secondary"
            }`}>
              {result.value}
            </p>
          </motion.div>
        ))}
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="bg-gradient-to-br from-primary/10 via-secondary/10 to-primary/10 border border-primary/20 rounded-2xl p-6 shadow-lg"
      >
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center">
            <Brain className="w-6 h-6 text-primary-foreground" />
          </div>
          <div>
            <h2 className="text-2xl">Analyse IA en cours</h2>
            <p className="text-sm text-muted-foreground">
              Patient : Mme Fatima B. • Dernière analyse : Il y a 2h
            </p>
          </div>
        </div>
        <div className="w-full bg-muted rounded-full h-2 mb-2">
          <div className="bg-primary h-2 rounded-full" style={{ width: "78%" }}></div>
        </div>
        <p className="text-sm text-muted-foreground">
          Analyse des biomarqueurs et corrélation avec la base de données oncologique
        </p>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="bg-card border border-border rounded-2xl p-6 shadow-sm"
      >
        <div className="flex items-center gap-3 mb-6">
          <Sparkles className="w-6 h-6 text-secondary" />
          <h2 className="text-2xl">Recommandations IA</h2>
        </div>
        <div className="space-y-4">
          {aiSuggestions.map((suggestion, index) => (
            <div
              key={index}
              className="p-5 bg-muted/50 border border-border rounded-xl hover:border-primary transition-all"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="px-3 py-1 bg-secondary/20 text-secondary rounded-full text-xs font-medium">
                      {suggestion.type}
                    </span>
                    <span className="text-sm text-muted-foreground">
                      Confiance: {suggestion.confidence}%
                    </span>
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{suggestion.title}</h3>
                  <p className="text-muted-foreground mb-3">{suggestion.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {suggestion.evidence.map((ev, i) => (
                      <span
                        key={i}
                        className="px-2 py-1 bg-primary/10 text-primary rounded text-xs"
                      >
                        {ev}
                      </span>
                    ))}
                  </div>
                </div>
                <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
                  suggestion.confidence > 90
                    ? "bg-primary/20"
                    : suggestion.confidence > 80
                    ? "bg-secondary/20"
                    : "bg-muted"
                }`}>
                  <span className={`text-xl font-bold ${
                    suggestion.confidence > 90
                      ? "text-primary"
                      : suggestion.confidence > 80
                      ? "text-secondary"
                      : "text-muted-foreground"
                  }`}>
                    {suggestion.confidence}%
                  </span>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                  Voir détails
                </button>
                <button className="px-4 py-2 border border-border rounded-lg text-sm font-medium hover:bg-muted transition-colors">
                  Exporter rapport
                </button>
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="bg-card border border-border rounded-2xl p-6 shadow-sm"
      >
        <div className="flex items-center gap-3 mb-6">
          <FileSearch className="w-6 h-6 text-primary" />
          <h2 className="text-2xl">Essais cliniques éligibles</h2>
        </div>
        <div className="space-y-4">
          {clinicalTrials.map((trial) => (
            <div
              key={trial.id}
              className={`p-5 rounded-xl border-l-4 ${
                trial.eligible
                  ? "bg-primary/5 border-primary"
                  : "bg-muted/50 border-border"
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <span className="font-mono text-sm text-muted-foreground">
                      {trial.id}
                    </span>
                    <span className="px-2 py-1 bg-secondary/20 text-secondary rounded text-xs font-medium">
                      {trial.phase}
                    </span>
                  </div>
                  <h3 className="font-semibold text-lg mb-2">{trial.name}</h3>
                  <p className="text-sm text-muted-foreground">{trial.location}</p>
                </div>
                {trial.eligible && (
                  <span className="px-3 py-1 bg-primary text-primary-foreground rounded-full text-xs font-medium">
                    Éligible
                  </span>
                )}
              </div>
              {trial.eligible && (
                <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                  Soumettre candidature
                </button>
              )}
            </div>
          ))}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="bg-secondary/10 border border-secondary/30 rounded-2xl p-6"
      >
        <div className="flex items-start gap-4">
          <AlertCircle className="w-6 h-6 text-secondary flex-shrink-0 mt-1" />
          <div>
            <h3 className="font-semibold mb-2">Note importante</h3>
            <p className="text-sm text-muted-foreground">
              Les recommandations de l'IA sont fournies à titre informatif et ne remplacent pas le jugement clinique.
              Toutes les décisions thérapeutiques doivent être validées par le comité oncologique.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
