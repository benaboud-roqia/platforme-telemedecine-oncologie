import { Outlet, NavLink } from "react-router";
import {
  Video,
  FileText,
  Pill,
  ActivitySquare,
  Brain,
  MessageSquare,
  ShoppingBag,
  Heart,
  Calendar as CalendarIcon,
  LayoutDashboard,
  Menu,
  X
} from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";

const navItems = [
  { path: "/", label: "Tableau de bord", icon: LayoutDashboard },
  { path: "/consultation", label: "Consultation vidéo", icon: Video },
  { path: "/dossier", label: "Dossier médical", icon: FileText },
  { path: "/prescriptions", label: "Prescriptions", icon: Pill },
  { path: "/symptomes", label: "Suivi symptômes", icon: ActivitySquare },
  { path: "/ia-decision", label: "IA médicale", icon: Brain },
  { path: "/messagerie", label: "Messagerie", icon: MessageSquare },
  { path: "/pharmacie", label: "Pharmacie", icon: ShoppingBag },
  { path: "/soutien-psy", label: "Soutien psy", icon: Heart },
  { path: "/agenda", label: "Agenda", icon: CalendarIcon },
];

export function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <AnimatePresence mode="wait">
        {sidebarOpen && (
          <motion.aside
            initial={{ x: -280 }}
            animate={{ x: 0 }}
            exit={{ x: -280 }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="w-72 bg-sidebar text-sidebar-foreground flex flex-col border-r border-sidebar-border shadow-2xl"
          >
            <div className="p-6 border-b border-sidebar-border">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-sidebar-primary mb-1">
                    Shifaa
                  </h1>
                  <p className="text-sm text-sidebar-foreground/70">
                    Plateforme Oncologie
                  </p>
                </div>
                <button
                  onClick={() => setSidebarOpen(false)}
                  className="lg:hidden p-2 hover:bg-sidebar-accent rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <nav className="flex-1 p-4 overflow-y-auto">
              <ul className="space-y-1">
                {navItems.map((item, index) => (
                  <motion.li
                    key={item.path}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    <NavLink
                      to={item.path}
                      end={item.path === "/"}
                      className={({ isActive }) =>
                        `flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                          isActive
                            ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-lg"
                            : "hover:bg-sidebar-accent text-sidebar-foreground/80 hover:text-sidebar-foreground"
                        }`
                      }
                    >
                      {({ isActive }) => (
                        <>
                          <item.icon className={`w-5 h-5 ${isActive ? "animate-pulse" : ""}`} />
                          <span className="font-medium">{item.label}</span>
                        </>
                      )}
                    </NavLink>
                  </motion.li>
                ))}
              </ul>
            </nav>

            <div className="p-4 border-t border-sidebar-border">
              <div className="flex items-center gap-3 p-3 bg-sidebar-accent rounded-xl">
                <div className="w-10 h-10 rounded-full bg-sidebar-primary flex items-center justify-center">
                  <span className="text-sidebar-primary-foreground font-semibold">
                    AA
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">Dr. Amira Alaoui</p>
                  <p className="text-xs text-sidebar-foreground/60 truncate">
                    Oncologue
                  </p>
                </div>
              </div>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      <div className="flex-1 flex flex-col overflow-hidden">
        <header className="h-16 border-b border-border bg-card flex items-center px-6 shadow-sm">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-accent rounded-lg transition-colors mr-4"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <p className="text-sm text-muted-foreground">
              Lundi, 13 Avril 2026
            </p>
          </div>
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium">
              🇩🇿 Version Algérienne
            </span>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-8 bg-background">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
