import { motion } from "motion/react";
import { Activity, TrendingDown, TrendingUp, AlertCircle } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";

const painData = [
  { jour: "Lun", douleur: 3, fatigue: 5, nausee: 2 },
  { jour: "Mar", douleur: 4, fatigue: 6, nausee: 3 },
  { jour: "Mer", douleur: 6, fatigue: 7, nausee: 5 },
  { jour: "Jeu", douleur: 5, fatigue: 6, nausee: 4 },
  { jour: "Ven", douleur: 4, fatigue: 5, nausee: 3 },
  { jour: "Sam", douleur: 3, fatigue: 4, nausee: 2 },
  { jour: "Dim", douleur: 3, fatigue: 4, nausee: 2 },
];

const symptomRadar = [
  { symptom: "Douleur", value: 4 },
  { symptom: "Fatigue", value: 6 },
  { symptom: "Nausée", value: 3 },
  { symptom: "Appétit", value: 5 },
  { symptom: "Sommeil", value: 4 },
  { symptom: "Anxiété", value: 5 },
];

const recentEntries = [
  {
    date: "Aujourd'hui, 09:30",
    symptoms: "Douleur modérée (4/10), Fatigue importante",
    ecog: "ECOG 1",
    notes: "Légère amélioration depuis hier",
    alert: false
  },
  {
    date: "Hier, 18:45",
    symptoms: "Douleur forte (7/10), Nausées",
    ecog: "ECOG 2",
    notes: "Prise d'anti-douleur à 18h",
    alert: true
  },
  {
    date: "12 Avril, 14:20",
    symptoms: "Fatigue modérée, Appétit réduit",
    ecog: "ECOG 1",
    notes: "Repos dans l'après-midi",
    alert: false
  },
];

const symptoms = [
  "Douleur",
  "Fatigue",
  "Nausée",
  "Vomissements",
  "Perte d'appétit",
  "Insomnie",
  "Anxiété",
  "Diarrhée"
];

export function SymptomTracking() {
  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl mb-2">Suivi des symptômes</h1>
          <p className="text-muted-foreground">
            Journal quotidien et analyse des tendances
          </p>
        </div>
        <button className="px-6 py-3 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors flex items-center gap-2">
          <Activity className="w-5 h-5" />
          Nouvelle entrée
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {[
          { label: "Douleur moyenne", value: "4.2/10", trend: "down", color: "text-primary" },
          { label: "Niveau fatigue", value: "6.0/10", trend: "down", color: "text-secondary" },
          { label: "Score ECOG", value: "1", trend: "stable", color: "text-chart-3" },
          { label: "Alertes actives", value: "2", trend: "up", color: "text-destructive" },
        ].map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-card border border-border rounded-2xl p-6 shadow-sm"
          >
            <p className="text-sm text-muted-foreground mb-2">{stat.label}</p>
            <div className="flex items-end justify-between">
              <p className={`text-3xl font-bold ${stat.color}`}>{stat.value}</p>
              {stat.trend === "down" && <TrendingDown className="w-5 h-5 text-primary" />}
              {stat.trend === "up" && <TrendingUp className="w-5 h-5 text-destructive" />}
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-card border border-border rounded-2xl p-6 shadow-sm"
        >
          <h2 className="text-2xl mb-6">Évolution sur 7 jours</h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={painData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E8DDD3" />
              <XAxis dataKey="jour" stroke="#6B7C77" />
              <YAxis stroke="#6B7C77" domain={[0, 10]} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#ffffff",
                  border: "1px solid #E8DDD3",
                  borderRadius: "12px",
                }}
              />
              <Line type="monotone" dataKey="douleur" stroke="#4A7C59" strokeWidth={3} dot={{ r: 5 }} />
              <Line type="monotone" dataKey="fatigue" stroke="#D2886F" strokeWidth={3} dot={{ r: 5 }} />
              <Line type="monotone" dataKey="nausee" stroke="#8FA998" strokeWidth={3} dot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
          <div className="flex items-center justify-center gap-6 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-primary"></div>
              <span className="text-sm text-muted-foreground">Douleur</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-secondary"></div>
              <span className="text-sm text-muted-foreground">Fatigue</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-chart-3"></div>
              <span className="text-sm text-muted-foreground">Nausée</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-card border border-border rounded-2xl p-6 shadow-sm"
        >
          <h2 className="text-2xl mb-6">Vue d'ensemble symptômes</h2>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={symptomRadar}>
              <PolarGrid stroke="#E8DDD3" />
              <PolarAngleAxis dataKey="symptom" stroke="#6B7C77" />
              <PolarRadiusAxis angle={90} domain={[0, 10]} stroke="#6B7C77" />
              <Radar name="Intensité" dataKey="value" stroke="#4A7C59" fill="#4A7C59" fillOpacity={0.6} />
            </RadarChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="bg-card border border-border rounded-2xl p-6 shadow-sm"
      >
        <h2 className="text-2xl mb-6">Entrées récentes</h2>
        <div className="space-y-4">
          {recentEntries.map((entry, index) => (
            <div
              key={index}
              className={`p-5 rounded-xl border-l-4 ${
                entry.alert
                  ? "bg-destructive/5 border-destructive"
                  : "bg-muted/50 border-primary"
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">{entry.date}</p>
                  <p className="font-medium mb-1">{entry.symptoms}</p>
                </div>
                {entry.alert && (
                  <div className="flex items-center gap-2 px-3 py-1 bg-destructive/10 text-destructive rounded-full text-sm">
                    <AlertCircle className="w-4 h-4" />
                    Alerte
                  </div>
                )}
              </div>
              <div className="flex items-center gap-4 text-sm">
                <span className="px-3 py-1 bg-primary/10 text-primary rounded-full font-medium">
                  {entry.ecog}
                </span>
                <span className="text-muted-foreground">{entry.notes}</span>
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="bg-card border border-border rounded-2xl p-6 shadow-sm"
      >
        <h2 className="text-2xl mb-6">Ajouter une nouvelle entrée</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          {symptoms.map((symptom) => (
            <button
              key={symptom}
              className="px-4 py-3 border border-border rounded-xl hover:border-primary hover:bg-primary/5 transition-all text-sm font-medium"
            >
              {symptom}
            </button>
          ))}
        </div>
        <div className="space-y-4">
          <div>
            <label className="block mb-2">Intensité de la douleur (0-10)</label>
            <input
              type="range"
              min="0"
              max="10"
              className="w-full"
            />
          </div>
          <div>
            <label className="block mb-2">Notes supplémentaires</label>
            <textarea
              className="w-full h-24 p-3 bg-muted/50 border border-border rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="Décrivez vos symptômes..."
            />
          </div>
          <button className="w-full px-6 py-3 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-colors">
            Enregistrer l'entrée
          </button>
        </div>
      </motion.div>
    </div>
  );
}
