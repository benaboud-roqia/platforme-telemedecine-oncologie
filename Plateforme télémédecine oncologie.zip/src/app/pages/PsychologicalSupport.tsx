import { motion } from "motion/react";
import { Heart, Video, Users, BookOpen, Headphones, Calendar } from "lucide-react";

const psychologists = [
  {
    name: "Dr. Samira Belkacem",
    specialty: "Psycho-oncologue",
    experience: "15 ans d'expérience",
    availability: "Disponible aujourd'hui",
    rating: 4.9,
    avatar: "SB"
  },
  {
    name: "Dr. Yacine Meziani",
    specialty: "Thérapeute spécialisé",
    experience: "10 ans d'expérience",
    availability: "Disponible demain",
    rating: 4.8,
    avatar: "YM"
  },
];

const supportGroups = [
  {
    name: "Groupe de soutien - Cancer du sein",
    participants: 12,
    nextSession: "15 Avril 2026, 16:00",
    language: "Français/Arabe",
    type: "Virtuel"
  },
  {
    name: "Atelier gestion du stress",
    participants: 8,
    nextSession: "17 Avril 2026, 14:00",
    language: "Français",
    type: "Virtuel"
  },
  {
    name: "Cercle de parole - Aidants",
    participants: 15,
    nextSession: "20 Avril 2026, 10:00",
    language: "Français/Arabe",
    type: "Hybride"
  },
];

const resources = [
  {
    title: "Méditation guidée - Gestion de l'anxiété",
    duration: "15 min",
    type: "Audio",
    category: "Relaxation"
  },
  {
    title: "Nutrition pendant la chimiothérapie",
    duration: "Lecture 10 min",
    type: "Article",
    category: "Nutrition"
  },
  {
    title: "Exercices de respiration",
    duration: "8 min",
    type: "Vidéo",
    category: "Bien-être"
  },
  {
    title: "Témoignages de patients",
    duration: "20 min",
    type: "Podcast",
    category: "Inspiration"
  },
];

export function PsychologicalSupport() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl mb-2">Soutien psychologique</h1>
        <p className="text-muted-foreground">
          Accompagnement psychologique et ressources de bien-être
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="lg:col-span-2 space-y-6"
        >
          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <Video className="w-6 h-6 text-primary" />
              <h2 className="text-2xl">Psycho-oncologues disponibles</h2>
            </div>
            <div className="space-y-4">
              {psychologists.map((psychologist, index) => (
                <div
                  key={index}
                  className="p-5 bg-muted/50 border border-border rounded-xl hover:border-primary transition-all"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-primary font-bold text-lg">
                        {psychologist.avatar}
                      </span>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-semibold text-lg mb-1">
                            {psychologist.name}
                          </h3>
                          <p className="text-sm text-primary mb-1">
                            {psychologist.specialty}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {psychologist.experience}
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-1 mb-1">
                            <span className="text-lg">⭐</span>
                            <span className="font-semibold">{psychologist.rating}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 mb-3">
                        <span className="px-3 py-1 bg-primary/20 text-primary rounded-full text-xs font-medium">
                          {psychologist.availability}
                        </span>
                      </div>
                      <div className="flex gap-2">
                        <button className="flex-1 px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors flex items-center justify-center gap-2">
                          <Video className="w-4 h-4" />
                          Prendre rendez-vous
                        </button>
                        <button className="px-4 py-2 border border-border rounded-lg text-sm font-medium hover:bg-muted transition-colors">
                          Profil
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <Users className="w-6 h-6 text-secondary" />
              <h2 className="text-2xl">Groupes de soutien</h2>
            </div>
            <div className="space-y-4">
              {supportGroups.map((group, index) => (
                <div
                  key={index}
                  className="p-5 bg-muted/50 rounded-xl border border-border"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-lg mb-2">{group.name}</h3>
                      <div className="flex flex-wrap gap-3 text-sm text-muted-foreground mb-2">
                        <span className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          {group.participants} participants
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {group.nextSession}
                        </span>
                      </div>
                      <div className="flex gap-2">
                        <span className="px-2 py-1 bg-primary/10 text-primary rounded text-xs font-medium">
                          {group.language}
                        </span>
                        <span className="px-2 py-1 bg-secondary/10 text-secondary rounded text-xs font-medium">
                          {group.type}
                        </span>
                      </div>
                    </div>
                  </div>
                  <button className="w-full px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                    Rejoindre le groupe
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <BookOpen className="w-6 h-6 text-primary" />
              <h2 className="text-2xl">Ressources d'accompagnement</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {resources.map((resource, index) => (
                <div
                  key={index}
                  className="p-4 bg-muted/50 rounded-xl hover:bg-muted transition-colors cursor-pointer"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <p className="font-medium mb-2">{resource.title}</p>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        {resource.type === "Audio" && <Headphones className="w-4 h-4" />}
                        {resource.type === "Vidéo" && <Video className="w-4 h-4" />}
                        {resource.type === "Article" && <BookOpen className="w-4 h-4" />}
                        {resource.type === "Podcast" && <Headphones className="w-4 h-4" />}
                        <span>{resource.duration}</span>
                      </div>
                    </div>
                  </div>
                  <span className="px-2 py-1 bg-primary/10 text-primary rounded text-xs font-medium">
                    {resource.category}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-6"
        >
          <div className="bg-gradient-to-br from-secondary to-secondary/80 text-white rounded-2xl p-6 shadow-lg">
            <Heart className="w-12 h-12 mb-4 opacity-90" />
            <h3 className="text-xl mb-3">Besoin d'aide immédiate ?</h3>
            <p className="text-sm text-white/90 mb-4">
              Notre équipe de psycho-oncologues est disponible 24/7 pour un soutien d'urgence.
            </p>
            <button className="w-full px-4 py-3 bg-white/20 backdrop-blur-sm rounded-lg font-medium hover:bg-white/30 transition-colors">
              Contacter maintenant
            </button>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <h3 className="font-semibold mb-4">Prochaines sessions</h3>
            <div className="space-y-3">
              <div className="p-3 bg-primary/10 rounded-lg">
                <p className="text-sm font-medium mb-1">Consultation Dr. Belkacem</p>
                <p className="text-xs text-muted-foreground">
                  Demain, 15 Avril à 10:00
                </p>
              </div>
              <div className="p-3 bg-secondary/10 rounded-lg">
                <p className="text-sm font-medium mb-1">Groupe de soutien</p>
                <p className="text-xs text-muted-foreground">
                  15 Avril à 16:00
                </p>
              </div>
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <h3 className="font-semibold mb-4">État émotionnel</h3>
            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">Anxiété</span>
                  <span className="text-sm font-medium">Modérée</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-secondary h-2 rounded-full"
                    style={{ width: "45%" }}
                  ></div>
                </div>
              </div>
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm text-muted-foreground">Bien-être</span>
                  <span className="text-sm font-medium">Bon</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full"
                    style={{ width: "70%" }}
                  ></div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-primary/10 border border-primary/20 rounded-2xl p-6">
            <h3 className="font-semibold mb-2">Citation du jour</h3>
            <p className="text-sm text-muted-foreground italic">
              "La force ne vient pas du corps. Elle vient de la volonté."
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
