import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Dashboard } from "./pages/Dashboard";
import { VideoConsultation } from "./pages/VideoConsultation";
import { MedicalRecord } from "./pages/MedicalRecord";
import { Prescriptions } from "./pages/Prescriptions";
import { SymptomTracking } from "./pages/SymptomTracking";
import { AIDecisionSupport } from "./pages/AIDecisionSupport";
import { SecureMessaging } from "./pages/SecureMessaging";
import { Pharmacy } from "./pages/Pharmacy";
import { PsychologicalSupport } from "./pages/PsychologicalSupport";
import { Calendar } from "./pages/Calendar";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: "consultation", Component: VideoConsultation },
      { path: "dossier", Component: MedicalRecord },
      { path: "prescriptions", Component: Prescriptions },
      { path: "symptomes", Component: SymptomTracking },
      { path: "ia-decision", Component: AIDecisionSupport },
      { path: "messagerie", Component: SecureMessaging },
      { path: "pharmacie", Component: Pharmacy },
      { path: "soutien-psy", Component: PsychologicalSupport },
      { path: "agenda", Component: Calendar },
    ],
  },
]);
