import { motion } from "motion/react";
import { ShoppingBag, MapPin, Truck, Bell, Clock, CheckCircle2 } from "lucide-react";

const pharmacies = [
  {
    name: "Pharmacie Centrale",
    address: "12 Rue Didouche Mourad, Alger",
    distance: "1.2 km",
    hours: "08:00 - 20:00",
    partner: true,
    available: true
  },
  {
    name: "Pharmacie El Biar",
    address: "Avenue Mohamed V, El Biar",
    distance: "2.5 km",
    hours: "08:30 - 19:00",
    partner: true,
    available: true
  },
  {
    name: "Pharmacie Ben Aknoun",
    address: "Cité Ben Aknoun, Alger",
    distance: "3.8 km",
    hours: "09:00 - 18:00",
    partner: false,
    available: false
  },
];

const activeOrders = [
  {
    id: "CMD-2026-0423",
    date: "12 Avril 2026",
    patient: "Mme Fatima B.",
    items: ["Paclitaxel 175mg", "Ondansétron 8mg"],
    pharmacy: "Pharmacie Centrale",
    status: "En livraison",
    estimated: "Aujourd'hui 15:00"
  },
  {
    id: "CMD-2026-0421",
    date: "10 Avril 2026",
    patient: "M. Karim H.",
    items: ["Cisplatine 100mg", "Dexaméthasone"],
    pharmacy: "Pharmacie El Biar",
    status: "Livrée",
    estimated: "10 Avril 14:30"
  },
];

const reminders = [
  {
    medication: "Ondansétron 8mg",
    time: "20:00",
    patient: "Mme Fatima B.",
    taken: false
  },
  {
    medication: "Dexaméthasone 4mg",
    time: "08:00",
    patient: "M. Karim H.",
    taken: true
  },
];

export function Pharmacy() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl mb-2">Pharmacie & Livraison</h1>
        <p className="text-muted-foreground">
          Gestion des ordonnances et livraison à domicile
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="lg:col-span-2 space-y-6"
        >
          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl">Commandes actives</h2>
              <Truck className="w-6 h-6 text-primary" />
            </div>
            <div className="space-y-4">
              {activeOrders.map((order) => (
                <div
                  key={order.id}
                  className="p-5 bg-muted/50 border border-border rounded-xl"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <p className="font-mono text-sm text-muted-foreground mb-1">
                        {order.id}
                      </p>
                      <p className="font-semibold text-lg mb-1">{order.patient}</p>
                      <p className="text-sm text-muted-foreground">{order.date}</p>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      order.status === "En livraison"
                        ? "bg-secondary/20 text-secondary"
                        : "bg-primary/20 text-primary"
                    }`}>
                      {order.status}
                    </span>
                  </div>

                  <div className="mb-4">
                    <p className="text-sm text-muted-foreground mb-2">Médicaments :</p>
                    <div className="flex flex-wrap gap-2">
                      {order.items.map((item, i) => (
                        <span
                          key={i}
                          className="px-3 py-1 bg-primary/10 text-primary rounded-lg text-sm"
                        >
                          {item}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-background rounded-lg">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm">{order.pharmacy}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="w-4 h-4" />
                      {order.estimated}
                    </div>
                  </div>

                  {order.status === "En livraison" && (
                    <div className="mt-4">
                      <div className="w-full bg-muted rounded-full h-2">
                        <div
                          className="bg-primary h-2 rounded-full transition-all duration-500"
                          style={{ width: "65%" }}
                        ></div>
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        En route vers le domicile du patient
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <MapPin className="w-6 h-6 text-secondary" />
              <h2 className="text-2xl">Pharmacies partenaires</h2>
            </div>
            <div className="space-y-4">
              {pharmacies.map((pharmacy, index) => (
                <div
                  key={index}
                  className={`p-5 rounded-xl border-l-4 ${
                    pharmacy.partner
                      ? "bg-primary/5 border-primary"
                      : "bg-muted/50 border-border"
                  }`}
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold text-lg">{pharmacy.name}</h3>
                        {pharmacy.partner && (
                          <span className="px-2 py-1 bg-primary/20 text-primary rounded text-xs font-medium">
                            Partenaire
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mb-1">
                        {pharmacy.address}
                      </p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {pharmacy.distance}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {pharmacy.hours}
                        </span>
                      </div>
                    </div>
                    {pharmacy.available && (
                      <span className="px-3 py-1 bg-primary text-primary-foreground rounded-full text-xs font-medium">
                        Disponible
                      </span>
                    )}
                  </div>
                  {pharmacy.partner && (
                    <button className="w-full px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                      Envoyer ordonnance
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-6"
        >
          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <div className="flex items-center gap-3 mb-6">
              <Bell className="w-6 h-6 text-secondary" />
              <h2 className="text-xl">Rappels de prise</h2>
            </div>
            <div className="space-y-3">
              {reminders.map((reminder, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-xl ${
                    reminder.taken
                      ? "bg-primary/10 border border-primary/20"
                      : "bg-secondary/10 border border-secondary/20"
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <p className="font-medium mb-1">{reminder.medication}</p>
                      <p className="text-sm text-muted-foreground">
                        {reminder.patient}
                      </p>
                    </div>
                    {reminder.taken ? (
                      <CheckCircle2 className="w-5 h-5 text-primary" />
                    ) : (
                      <span className="px-2 py-1 bg-secondary text-white rounded text-xs font-medium">
                        {reminder.time}
                      </span>
                    )}
                  </div>
                  {!reminder.taken && (
                    <button className="w-full px-3 py-2 bg-secondary text-white rounded-lg text-sm font-medium hover:bg-secondary/90 transition-colors mt-2">
                      Marquer comme pris
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground rounded-2xl p-6 shadow-lg">
            <ShoppingBag className="w-12 h-12 mb-4 opacity-90" />
            <h3 className="text-xl mb-2">Livraison rapide</h3>
            <p className="text-sm text-primary-foreground/90 mb-4">
              Recevez vos médicaments à domicile en moins de 4h avec nos pharmacies partenaires à Alger.
            </p>
            <button className="w-full px-4 py-3 bg-white/20 backdrop-blur-sm rounded-lg font-medium hover:bg-white/30 transition-colors">
              Commander maintenant
            </button>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 shadow-sm">
            <h3 className="font-semibold mb-3">Statistiques</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Commandes ce mois</span>
                <span className="font-semibold">12</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Temps moyen livraison</span>
                <span className="font-semibold">3h 20min</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Taux de satisfaction</span>
                <span className="font-semibold text-primary">98%</span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
