import { motion } from "motion/react";
import {
  Users,
  Calendar,
  AlertCircle,
  TrendingUp,
  Video,
  MessageSquare,
  Bell,
  Activity
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";

const statsData = [
  { label: "Patients actifs", value: "247", change: "+12%", icon: Users, color: "bg-primary" },
  { label: "Consultations ce mois", value: "89", change: "+8%", icon: Video, color: "bg-secondary" },
  { label: "Messages non lus", value: "23", change: "5 urgents", icon: MessageSquare, color: "bg-chart-3" },
  { label: "Rendez-vous aujourd'hui", value: "7", change: "2 en cours", icon: Calendar, color: "bg-chart-4" },
];

const consultationData = [
  { mois: "Oct", consultations: 65 },
  { mois: "Nov", consultations: 78 },
  { mois: "Dec", consultations: 82 },
  { mois: "Jan", consultations: 71 },
  { mois: "Fev", consultations: 89 },
  { mois: "Mar", consultations: 95 },
];

const alertsData = [
  {
    id: 1,
    patient: "Mme Fatima B.",
    message: "Score douleur élevé (8/10) - Nécessite attention",
    time: "Il y a 15 min",
    priority: "high",
  },
  {
    id: 2,
    patient: "M. Karim H.",
    message: "Résultats IRM disponibles pour consultation",
    time: "Il y a 1h",
    priority: "medium",
  },
  {
    id: 3,
    patient: "Mme Amina D.",
    message: "Rappel : Cycle chimio prévu demain 14h",
    time: "Il y a 2h",
    priority: "low",
  },
];

const upcomingAppointments = [
  { time: "09:00", patient: "M. Ahmed K.", type: "Consultation suivi", status: "confirmé" },
  { time: "10:30", patient: "Mme Sarah L.", type: "Résultats analyses", status: "en cours" },
  { time: "14:00", patient: "M. Yacine M.", type: "Première consultation", status: "confirmé" },
  { time: "15:30", patient: "Mme Nadia B.", type: "Téléconsultation", status: "confirmé" },
];

export function Dashboard() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl mb-2">Tableau de bord</h1>
        <p className="text-muted-foreground">
          Vue d'ensemble de votre activité médicale
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsData.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-card border border-border rounded-2xl p-6 shadow-sm hover:shadow-xl transition-shadow duration-300"
          >
            <div className="flex items-start justify-between mb-4">
              <div className={`${stat.color} p-3 rounded-xl text-white`}>
                <stat.icon className="w-6 h-6" />
              </div>
              <span className="text-xs font-medium text-muted-foreground bg-muted px-2 py-1 rounded-full">
                {stat.change}
              </span>
            </div>
            <p className="text-3xl font-bold mb-1">{stat.value}</p>
            <p className="text-sm text-muted-foreground">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
          className="lg:col-span-2 bg-card border border-border rounded-2xl p-6 shadow-sm"
        >
          <div className="flex items-center justify-between mb-6">
            <div>
              <h2 className="text-2xl mb-1">Évolution des consultations</h2>
              <p className="text-sm text-muted-foreground">
                Nombre de consultations par mois
              </p>
            </div>
            <TrendingUp className="w-6 h-6 text-primary" />
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={consultationData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E8DDD3" />
              <XAxis dataKey="mois" stroke="#6B7C77" />
              <YAxis stroke="#6B7C77" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#ffffff",
                  border: "1px solid #E8DDD3",
                  borderRadius: "12px",
                }}
              />
              <Bar dataKey="consultations" fill="#4A7C59" radius={[8, 8, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-card border border-border rounded-2xl p-6 shadow-sm"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl">Rendez-vous du jour</h2>
            <Calendar className="w-6 h-6 text-secondary" />
          </div>
          <div className="space-y-4">
            {upcomingAppointments.map((apt, index) => (
              <div
                key={index}
                className="flex items-start gap-3 p-3 bg-muted/50 rounded-xl hover:bg-muted transition-colors"
              >
                <div className="text-primary font-semibold text-sm min-w-[50px]">
                  {apt.time}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{apt.patient}</p>
                  <p className="text-xs text-muted-foreground truncate">
                    {apt.type}
                  </p>
                </div>
                <span
                  className={`text-xs px-2 py-1 rounded-full ${
                    apt.status === "en cours"
                      ? "bg-secondary/20 text-secondary"
                      : "bg-primary/20 text-primary"
                  }`}
                >
                  {apt.status}
                </span>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="bg-card border border-border rounded-2xl p-6 shadow-sm"
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl mb-1">Alertes et notifications</h2>
            <p className="text-sm text-muted-foreground">
              Alertes importantes nécessitant votre attention
            </p>
          </div>
          <Bell className="w-6 h-6 text-destructive" />
        </div>
        <div className="space-y-3">
          {alertsData.map((alert) => (
            <div
              key={alert.id}
              className={`flex items-start gap-4 p-4 rounded-xl border-l-4 ${
                alert.priority === "high"
                  ? "bg-destructive/5 border-destructive"
                  : alert.priority === "medium"
                  ? "bg-secondary/5 border-secondary"
                  : "bg-primary/5 border-primary"
              }`}
            >
              <AlertCircle
                className={`w-5 h-5 mt-0.5 ${
                  alert.priority === "high"
                    ? "text-destructive"
                    : alert.priority === "medium"
                    ? "text-secondary"
                    : "text-primary"
                }`}
              />
              <div className="flex-1">
                <p className="font-medium mb-1">{alert.patient}</p>
                <p className="text-sm text-muted-foreground mb-2">
                  {alert.message}
                </p>
                <p className="text-xs text-muted-foreground">{alert.time}</p>
              </div>
              <button className="px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                Voir
              </button>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
