import { motion } from "motion/react";
import { Video, Phone, Mic, MicOff, VideoOff, Share2, Users, Clock } from "lucide-react";
import { useState } from "react";

const waitingPatients = [
  { id: 1, name: "Mme Fatima B.", time: "09:00", reason: "Suivi post-chimio", waiting: "5 min" },
  { id: 2, name: "M. Karim H.", time: "09:30", reason: "Résultats analyses", waiting: "Prêt" },
  { id: 3, name: "Mme Sarah L.", time: "10:00", reason: "Consultation suivi", waiting: "En attente" },
];

const consultationHistory = [
  { date: "10 Avril 2026", patient: "M. Ahmed K.", duration: "32 min", notes: "Révisé" },
  { date: "08 Avril 2026", patient: "Mme Nadia B.", duration: "28 min", notes: "Révisé" },
  { date: "05 Avril 2026", patient: "M. Yacine M.", duration: "45 min", notes: "Révisé" },
];

export function VideoConsultation() {
  const [inCall, setInCall] = useState(false);
  const [micOn, setMicOn] = useState(true);
  const [videoOn, setVideoOn] = useState(true);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-4xl mb-2">Consultation vidéo</h1>
        <p className="text-muted-foreground">
          Téléconsultations sécurisées avec vos patients
        </p>
      </div>

      {!inCall ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:col-span-2 bg-card border border-border rounded-2xl p-8 shadow-sm"
          >
            <div className="text-center py-12">
              <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Video className="w-12 h-12 text-primary" />
              </div>
              <h2 className="text-2xl mb-3">Salle de consultation</h2>
              <p className="text-muted-foreground mb-8 max-w-md mx-auto">
                Commencez une consultation vidéo sécurisée avec vos patients en attente
              </p>
              <button
                onClick={() => setInCall(true)}
                className="px-8 py-4 bg-primary text-primary-foreground rounded-xl font-medium hover:bg-primary/90 transition-all shadow-lg hover:shadow-xl"
              >
                Démarrer la consultation
              </button>
            </div>

            <div className="border-t border-border pt-8 mt-8">
              <h3 className="text-xl mb-4">Historique des consultations</h3>
              <div className="space-y-3">
                {consultationHistory.map((consultation, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-4 bg-muted/50 rounded-xl hover:bg-muted transition-colors"
                  >
                    <div>
                      <p className="font-medium">{consultation.patient}</p>
                      <p className="text-sm text-muted-foreground">{consultation.date}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="text-sm text-muted-foreground flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {consultation.duration}
                      </span>
                      <button className="px-4 py-2 bg-primary/10 text-primary rounded-lg text-sm font-medium hover:bg-primary/20 transition-colors">
                        {consultation.notes}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-card border border-border rounded-2xl p-6 shadow-sm"
          >
            <div className="flex items-center gap-3 mb-6">
              <Users className="w-6 h-6 text-secondary" />
              <h2 className="text-2xl">Salle d'attente</h2>
            </div>
            <div className="space-y-4">
              {waitingPatients.map((patient) => (
                <div
                  key={patient.id}
                  className="p-4 bg-muted/50 rounded-xl border border-border hover:border-primary transition-colors"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="font-medium mb-1">{patient.name}</p>
                      <p className="text-sm text-muted-foreground">{patient.time}</p>
                    </div>
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      patient.waiting === "Prêt"
                        ? "bg-primary/20 text-primary"
                        : "bg-secondary/20 text-secondary"
                    }`}>
                      {patient.waiting}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">{patient.reason}</p>
                  <button className="w-full px-4 py-2 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:bg-primary/90 transition-colors">
                    Appeler le patient
                  </button>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      ) : (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-card border border-border rounded-2xl overflow-hidden shadow-2xl"
        >
          <div className="relative bg-gradient-to-br from-primary/20 to-secondary/20 aspect-video flex items-center justify-center">
            <div className="text-center">
              <div className="w-32 h-32 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-4xl text-primary-foreground font-bold">FB</span>
              </div>
              <h3 className="text-2xl mb-1">Mme Fatima B.</h3>
              <p className="text-muted-foreground">Consultation en cours...</p>
            </div>

            <div className="absolute top-4 right-4 bg-card/90 backdrop-blur-sm px-4 py-2 rounded-lg border border-border">
              <p className="text-sm font-medium flex items-center gap-2">
                <span className="w-2 h-2 bg-destructive rounded-full animate-pulse"></span>
                12:34
              </p>
            </div>

            <div className="absolute bottom-4 left-4 right-4 flex items-center justify-center gap-4">
              <button
                onClick={() => setMicOn(!micOn)}
                className={`p-4 rounded-full transition-all ${
                  micOn ? "bg-card/90 hover:bg-card" : "bg-destructive hover:bg-destructive/90"
                }`}
              >
                {micOn ? <Mic className="w-6 h-6" /> : <MicOff className="w-6 h-6 text-white" />}
              </button>

              <button
                onClick={() => setVideoOn(!videoOn)}
                className={`p-4 rounded-full transition-all ${
                  videoOn ? "bg-card/90 hover:bg-card" : "bg-destructive hover:bg-destructive/90"
                }`}
              >
                {videoOn ? <Video className="w-6 h-6" /> : <VideoOff className="w-6 h-6 text-white" />}
              </button>

              <button className="p-4 rounded-full bg-card/90 hover:bg-card transition-all">
                <Share2 className="w-6 h-6" />
              </button>

              <button
                onClick={() => setInCall(false)}
                className="px-6 py-4 bg-destructive text-white rounded-full hover:bg-destructive/90 transition-all flex items-center gap-2"
              >
                <Phone className="w-5 h-5" />
                Terminer
              </button>
            </div>
          </div>

          <div className="p-6 border-t border-border">
            <h3 className="font-medium mb-3">Notes de consultation</h3>
            <textarea
              className="w-full h-24 p-3 bg-muted/50 border border-border rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="Prenez des notes pendant la consultation..."
            />
          </div>
        </motion.div>
      )}
    </div>
  );
}
