
  # Plateforme télémédecine oncologie

  This is a code bundle for Plateforme télémédecine oncologie. The original project is available at https://www.figma.com/design/vn3VDma7ObsWMQgtBICyjQ/Plateforme-t%C3%A9l%C3%A9m%C3%A9decine-oncologie.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  